<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2 style="color:red;">FISH ITEMS</h2>
            </div>
            <div class="pull-right">
                
            </div>
        </div>
    </div>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
    
    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                 <h2> </h2>
                 </div>
                 <div class="pull-right">
                     
                </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                
                <h2><?php echo e($customer->fish_name); ?></h2>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                
                <img width="190" src="../storage/app/uploads/employee/<?php echo e($customer -> image); ?>"   alt = "<?php echo $customer -> image ?> ">
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Price:</strong>
                <?php echo e($customer->price); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Available Quantity:</strong>
                 <?php echo e($customer->quantity); ?> Kg
            </div>
        </div> 
       <a class="btn btn-primary" href="<?php echo e(route('customer.edit',$customer->id)); ?>">Order</a>
       
       
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php echo $customers->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fish\resources\views/customers/index.blade.php ENDPATH**/ ?>