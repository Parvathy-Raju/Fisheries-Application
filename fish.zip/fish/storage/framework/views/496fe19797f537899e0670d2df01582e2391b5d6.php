
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fisheries</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
 
<div class="container">
<form action="<?php echo e(route('addimage')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Name:</strong>
            
            <input type="text" name="name"/>
        </div>
        
        <div class="form-group">
            <strong>Image:</strong>
            <input type="file" name="image"/>
            
        </div>
    </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <input type="submit" name="submit"  class="btn btn-primary" />
            
        </div>
 </div>
</form>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\fish\resources\views/employee.blade.php ENDPATH**/ ?>