<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;

class ImageController extends Controller
{
    public function show()
    {
       $employees = Employee::all();
       return view('display',['employees' => $employees]);
    }
}
