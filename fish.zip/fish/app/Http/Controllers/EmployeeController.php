<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
class EmployeeController extends Controller
{
    public function index()
    {
        return view('employee');
    }

    public function store(Request $request)
    {
        //return ('welcome!!');
        Employee::create($request->all());
        //return redirect()->route('employee.store');
       $employee = new Employee();
    //     $employee->name = $request->input('name');
       
       if ($request->hasFile('image')) {
       $file = $request->file('image');
       $extension = $file->getClientOriginalExtension();
       $filename = time() . '.' . $extension;
       $file->move('uploads/employee',$filename);
    //    storage::put('uploads/employee',$filename);
       $employee->image = $filename; 
        }
        else{
            return $request;
            $employee->image = '';
        }
       $employee->save();
       return view('employee')->with('employee',$employee);
    }
}