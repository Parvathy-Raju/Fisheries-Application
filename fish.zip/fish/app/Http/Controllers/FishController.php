<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Product;
class FishController extends Controller
{
    public function index()
    {
        $products = Product::latest()->paginate(10);
        return view('fishes.index',compact('products'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('fishes.create');
    }
    /**
     * Store a newly created resource in storage.z
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'fish_name' => 'required',
           // 'image' => 'required',
            'price' => 'required',
            'quantity' => 'required',
        ]);
        Product::create($request->all());
        //return redirect()->route('employee.store');
       $products = new Product();
    //     $employee->name = $request->input('name');
       
       if ($request->hasFile('image')) {
       $file = $request->file('image');
       $extension = $file->getClientOriginalExtension();
       $filename = time() . '.' . $extension;
       $file->move('uploads/fish',$filename);
    //    storage::put('uploads/employee',$filename);
       $products->image = $filename; 
        }
        else{
            return $request;
            $products->image = '';
        }
       $products->save();
       return view('fishes')->with('fishes',$products);
        
        Product::create($request->all());
        return redirect()->route('fishes.index')
                        ->with('success','fishe created successfully');
    }
    /**
     * Display the specified resource.
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Product $user)
    {
    //return $user;
        
    //    return view('fishes.show',compact('user'));
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $products)
    {
        //return $products;
        return view('fishes.edit',compact('products'));
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,Product $products)
    {
        request()->validate([
            'fish_name' => 'required',
            //'image' => 'required',
            'price' => 'required',
            'quantity' => 'required',
        ]);
        $products->update($request->all());
        return redirect()->route('fishes.index')
                        ->with('success','fish updated successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Product::destroy($id);
        return redirect()->route('fishes.index')
                        ->with('success','fish deleted successfully');
    }
}
