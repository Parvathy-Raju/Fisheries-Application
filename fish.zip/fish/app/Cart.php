<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
 
    protected $fillable = [
        'user_id', 'fish_id', 'fish_quantity', 'status'
    ];    //
}
