<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Name:</strong>
            {!! Form::text('fish_name', null, array('placeholder' => 'Name','class' => 'form-control' )) !!}
        </div>
        
         <div class="form-group">
            <strong>Price(1Kg):</strong>
           
            {!! Form::text('price', null, array('placeholder' => 'Price','class' => 'form-control')) !!}
        </div>
        <div class="form-group">
            <strong>Quantity:</strong>
            {!! Form::text('order_quantity', null, array('placeholder' => 'Quantity','class' => 'form-control')) !!}
            
       </div>
        
        <div class="form-group">
            <?php 
        $price='price';
        $quantity='order_quantity';
        $sum = 0;
        
        ?>
            <strong>Total Price:</strong>
            {{-- <a  href="" onclick='{{ $sum-> 'price' + 'quantity'}}';><i class="fa fa-pencil-square-o">Sum </i></a> --}}
            {{-- {!! Form::text('order_price', null, array('placeholder' => 'Quantity','class' => 'form-control', 'onclick' => "add('{{$sum}}');")) !!} --}}
        </div>
             <button type="submit" class="btn btn-primary" >Calculate</button>
       
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
