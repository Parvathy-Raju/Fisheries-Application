@extends('layouts.default')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2 style="color:red;">FISH ITEMS</h2>
            </div>
            <div class="pull-right">
                {{-- <a class="btn btn-success" href="{{ route('products.create') }}"> Create New fish</a> --}}
            </div>
        </div>
    </div>
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    
    @foreach ($customers as $customer)
    <div class="row">
        <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                 <h2> </h2>
                 </div>
                 <div class="pull-right">
                     {{-- <a class="btn btn-primary" href="{{ route('customers.index') }}"> Back</a>  --}}
                </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                
                <h2>{{ $customer->fish_name}}</h2>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                
                <img width="190" src="../storage/app/uploads/employee/{{$customer -> image}}"   alt = "<?php echo $customer -> image ?> ">
            </div>
        </div>
         <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Price:</strong>
                {{ $customer->price}}
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Available Quantity:</strong>
                 {{ $customer->quantity}} Kg
            </div>
        </div> 
       <a class="btn btn-primary" href="{{ route('customer.edit',$customer->id) }}">Order</a>
       {{-- <a class="btn btn-info" href="{{ route('customer.show',$customer->id) }}">Order</a> --}}
       
    </div>
    @endforeach
    {{-- </table> --}}
    {!! $customers->render() !!}
@endsection