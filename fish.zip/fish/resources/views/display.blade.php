@extends('layouts.default')
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Fishes CRUD</h2>
            </div>
            
        </div>
    </div>
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Image</th>
            
        </tr>
    @foreach ($employees as $employee)
    <tr>
        <td><?php echo $employee->id?></td>
        <td><?php echo $employee->name?></td>
        
        <td><img width="100" src="../storage/app/uploads/employee/{{$employee -> image}}"   alt = "<?php echo $employee -> image ?> "> </td>
    </tr>
    @endforeach
    </table>
   
@endsection