<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>Name:</strong>
            {!! Form::text('fish_name', null, array('placeholder' => 'Name','class' => 'form-control')) !!}
        </div>
        <div class="form-group">
            <strong>Image:</strong>
            {{-- <img width="100" src="../../../storage/app/uploads/employee/{{$product -> image}}"   alt = " "> --}}
            {!! Form::file('image', null, array('placeholder' => 'Image','class' => 'form-control')) !!}
        </div>
        <div class="form-group">
            <strong>Price (Per 1 Kg):</strong>
            {!! Form::text('price', null, array('placeholder' => 'Price','class' => 'form-control')) !!}
        </div>
        <div class="form-group">
            <strong>Available Quantity:</strong>
            {!! Form::text('quantity', null, array('placeholder' => 'Quantity','class' => 'form-control')) !!}
        
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
